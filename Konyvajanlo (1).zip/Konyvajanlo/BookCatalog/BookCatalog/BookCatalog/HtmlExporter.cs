﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;

namespace BookCatalog
{
    internal class HtmlExporter
    {
        public static void Export(List<Book> books)
        {
            string projectRoot = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", ".."));
            string outputDir = Path.Combine(projectRoot, "outputs");
            string templatePath = Path.Combine(projectRoot, "template", "template.html");
            string cssTargetPath = Path.Combine(outputDir, "style.css");
            string cssSourcePath = Path.Combine(projectRoot, "template", "style.css");
            string imagesSourceDir = Path.Combine(projectRoot, "template", "images");
            string imagesTargetDir = Path.Combine(outputDir, "images");
            if (!File.Exists(cssSourcePath))
            {
                cssSourcePath = Path.Combine(projectRoot, "template", "sytle.css");
            }

            Directory.CreateDirectory(outputDir);

            if (!File.Exists(templatePath))
            {
                Console.WriteLine("Hiba: a HTML sablonfájl nem található.");
                return;
            }

            if (File.Exists(cssSourcePath))
            {
                File.Copy(cssSourcePath, cssTargetPath, true);
            }

            CopyTemplateImages(imagesSourceDir, imagesTargetDir);

            string template = File.ReadAllText(templatePath, Encoding.UTF8);

            var sortedByRating = books.OrderByDescending(b => b.Rating).ThenBy(b => b.Title).ToList();
            var favorites = books.Where(b => b.IsFavorite).OrderByDescending(b => b.Rating).ToList();

            string itemsHtml = BuildItemsTableHtml(sortedByRating);
            string itemsPage = template.Replace("{{TITLE}}", "Összes könyv")
                                       .Replace("{{CONTENT}}", itemsHtml);
            File.WriteAllText(Path.Combine(outputDir, "items.html"), itemsPage, Encoding.UTF8);

            string favoritesHtml = BuildCardListHtml(favorites, "Még nincs kedvencként jelölt könyv.");
            string favoritesPage = template.Replace("{{TITLE}}", "Kedvencek")
                                           .Replace("{{CONTENT}}", favoritesHtml);
            File.WriteAllText(Path.Combine(outputDir, "favorites.html"), favoritesPage, Encoding.UTF8);

            string indexHtml = template.Replace("{{TITLE}}", "Könyvajánló")
                                       .Replace("{{CONTENT}}", BuildIndexContent(books, favorites, sortedByRating));
            File.WriteAllText(Path.Combine(outputDir, "index.html"), indexHtml, Encoding.UTF8);

            Console.WriteLine($"HTML export kész! Mappa: {outputDir}");
        }

        private static string BuildIndexContent(List<Book> books, List<Book> favorites, List<Book> sortedByRating)
        {
            var categoryCount = books.Select(b => b.Category)
                                     .Where(c => !string.IsNullOrWhiteSpace(c))
                                     .Distinct(StringComparer.OrdinalIgnoreCase)
                                     .Count();

            var topPicks = sortedByRating.Take(3).ToList();
            var sb = new StringBuilder();

            sb.AppendLine("<p>Tematikus könyvajánló gyűjtemény, ahol a legjobb értékelésű és kedvenc könyveket külön is kiemeljük.</p>");

            sb.AppendLine("<section class='stats'>");
            sb.AppendLine($"<p><strong>Összes könyv:</strong> {books.Count}</p>");
            sb.AppendLine($"<p><strong>Kedvencek:</strong> {favorites.Count}</p>");
            sb.AppendLine($"<p><strong>Kategóriák száma:</strong> {categoryCount}</p>");
            sb.AppendLine("</section>");

            sb.AppendLine("<section>");
            sb.AppendLine("<h3>Kiemelt könyvek</h3>");
            sb.AppendLine(BuildCardListHtml(topPicks, "Nincs még kiemelhető könyv."));
            sb.AppendLine("</section>");

            return sb.ToString();
        }

        private static string BuildItemsTableHtml(List<Book> books)
        {
            if (books.Count == 0)
            {
                return "<p>Nincs még egyetlen könyv sem a listában.</p>";
            }

            var sb = new StringBuilder();
            sb.AppendLine("<table>");
            sb.AppendLine("<thead><tr><th>Kép</th><th>Cím</th><th>Szerző</th><th>Kategória</th><th>Leírás</th><th>Értékelés</th><th>Kiadás éve</th></tr></thead>");
            sb.AppendLine("<tbody>");

            foreach (var b in books)
            {
                sb.AppendLine("<tr>");
                sb.AppendLine("<td><img class='thumb' src='images/book-placeholder.svg' alt='Könyv borító helyőrző'></td>");
                sb.AppendLine($"<td>{HtmlEncode(b.Title)}</td>");
                sb.AppendLine($"<td>{HtmlEncode(b.Author)}</td>");
                sb.AppendLine($"<td><span class='tag'>{HtmlEncode(b.Category)}</span></td>");
                sb.AppendLine($"<td>{HtmlEncode(b.Description)}</td>");
                sb.AppendLine($"<td>{b.Rating}/10</td>");
                sb.AppendLine($"<td>{b.Year}</td>");
                sb.AppendLine("</tr>");
            }

            sb.AppendLine("</tbody>");
            sb.AppendLine("</table>");

            return sb.ToString();
        }

        private static string BuildCardListHtml(List<Book> books, string emptyMessage)
        {
            if (books.Count == 0)
            {
                return $"<p>{HtmlEncode(emptyMessage)}</p>";
            }

            var sb = new StringBuilder();
            sb.AppendLine("<div class='card-container'>");

            foreach (var b in books)
            {
                string cardClass = b.IsFavorite ? "card favorite" : "card";
                sb.AppendLine($"<article class='{cardClass}'>");
                sb.AppendLine("<img class='cover' src='images/book-placeholder.svg' alt='Könyv borító helyőrző'>");
                sb.AppendLine($"<h3>{HtmlEncode(b.Title)}</h3>");
                sb.AppendLine($"<p><strong>Szerző:</strong> {HtmlEncode(b.Author)}</p>");
                sb.AppendLine($"<p><strong>Kategória:</strong> {HtmlEncode(b.Category)}</p>");
                sb.AppendLine($"<p>{HtmlEncode(b.Description)}</p>");
                sb.AppendLine($"<p><strong>Értékelés:</strong> {b.Rating}/10</p>");
                sb.AppendLine($"<p><strong>Kiadás éve:</strong> {b.Year}</p>");
                sb.AppendLine("</article>");
            }

            sb.AppendLine("</div>");
            return sb.ToString();
        }

        private static string HtmlEncode(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            // Keep UTF-8 letters (including accents) intact and escape only HTML-sensitive chars.
            return value
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;")
                .Replace("'", "&#39;");
        }

        private static void CopyTemplateImages(string sourceDir, string targetDir)
        {
            if (!Directory.Exists(sourceDir))
            {
                return;
            }

            Directory.CreateDirectory(targetDir);
            var imageFiles = Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories);

            foreach (var sourceFilePath in imageFiles)
            {
                var relativePath = Path.GetRelativePath(sourceDir, sourceFilePath);
                var targetFilePath = Path.Combine(targetDir, relativePath);
                var targetFileDir = Path.GetDirectoryName(targetFilePath);
                if (!string.IsNullOrWhiteSpace(targetFileDir))
                {
                    Directory.CreateDirectory(targetFileDir);
                }

                File.Copy(sourceFilePath, targetFilePath, true);
            }
        }
    }
}
